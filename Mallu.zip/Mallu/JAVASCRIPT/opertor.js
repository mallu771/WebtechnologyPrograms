//Arithmetic operator
// let a = 10;
// let b = 20;
// console.log("a+b=", a + b);
// console.log("a-b=", a - b);
// console.log("a*b=", a * b);
// console.log("a/b=", a / b);
// console.log("a%b=", a % b);
// console.log("a**b=", a ** b);


//Assignment operator
// let c = 10;
// c += 5;
// console.log(c);
// c -= 2;
// console.log(c);
// c *= 20;
// console.log(c);
// c /= 5;
// console.log(c);
// c **= 9;
// console.log(c);
// c %= 10;
// console.log(c);

//comparision operator
// let e = 10;
// let f = 10;
// console.log(e == f);
// console.log(e != f);
// console.log(e === f);
// console.log(e !== f);
// console.log(e > f);
// console.log(e < f);
// console.log(e >= f);
// console.log(e <= f);
//logical operator
let m = 10;
let n = 20;
console.log(m > 10 && n < 10);
console.log(m > 10 || n < 10);
console.log(!true);
console.log(!false);