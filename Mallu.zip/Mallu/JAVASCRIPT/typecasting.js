// //implicit type casting
// console.log(5 + 5); //cocate number 10
// console.log(5 - 5); // number is zero
// console.log(5 - '5'); //number is zero
// console.log(5 - 'a'); //NAN bcz it is not number

//explicit type casting
// let a = 10;
// console.log(a, typeof a);
// let b = String(20);
// console.log(b, typeof b);

// let s = 15;
// let s1 = String(s);
// console.log(s1, typeof s1);

// let c = Boolean("hi");
// console.log(c, typeof c);

// let d = "true";
// console.log(d, typeof d);
// let e = true;
// console.log(e, typeof e);

// let f = Number(102);
// console.log(f, typeof f);
// let g = Number('hhii');
// console.log(g, typeof g);