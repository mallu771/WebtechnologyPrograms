// let pmc = new Promise((resolve, reject) => {

//     let name = "hbd manja";
//     if (name == "hbd manja") {
//         resolve(name);
//     } else {
//         reject("the name is not harsha")
//     }
// })
// pmc.then((name) => {
//     console.log(name);
// }).catch((error) => {
//     console.log("the name is not harsha");
// }).finally(() => {
//     console.log("promises is finished");
// })

// let abc = new Promise((resolve, reject) => {
//     let name = 'mallu';
//     if (name == 'mallu')
//         resolve(name);
//     else
//         reject('name not mallu');
// })
// abc.then((name) => {
//     console.log("the name is " + name);
// }).catch((error) => {
//     console.log("Not name is " + name);
// }).finally(() => {
//     console.log("finally");
// })

let mg = new Promise((resolve, reject) => {
    let id = 10;
    if (id == 1)
        resolve(id)
    else
        reject(",anskdkdn")
})
mg.then((id) => {
    console.log("hinn");
}).catch((error) => {
    console.log("dsds");
}).finally(() => {
    console.log("jkjkl");
})