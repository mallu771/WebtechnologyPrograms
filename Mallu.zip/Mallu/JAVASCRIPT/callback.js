// function mul(res) {

//     let z = 4;
//     console.log(res);
//     console.log(res(2, 4))
// }
// mul(2);
// res(function(a, b) {
//     return a * b;
// })

// invoking fun
// function val() {
//     let v = 20;
//     console.log(v);
// }
// val()
// val()
// val()
(function val() {
        let v = 20;
        console.log(v);
    }
    ());