// let choice = () => {
//     return new promise((resolve, reject) => {
//         setTimeout(() => {
//             resolve(console.log("tell your choice"))
//         }, 3000)
//     })
// };

// async function kitchen() {
//     console.log("tomato");
//     console.log("potato");
//     await choice();
//     console.log("customer wants biryani");
//     console.log("chilly chicken");
// }
// kitchen()
let add = () => {
    return new Promise((resolve, reset) => {
        setInterval(() => {
            resolve(console.log("hii"))
        }, 2000)
    })
};

async function kas() {
    console.log("hello");
    await add();
    console.log("kkk");
    console.log("fds");
}
kas()
    // var myFirstWord = "Rahul";

// var mySecondWord = "honest";

// var myThirdWord = "hard working";

// var myFourthWord = "employee";


// // var FinalSentence = myFirstWord + " is a " + mySecondWord + " & " + myThirdWord + " & skilled " + myFourthWord + ".";
// // var FinalSentence = myFirstWord + "is a" + mySecondWord + "&" + myThirdWord + "& enthusiastic" + myFourthWord + ".";
// // var FinalSentence = myFirstWord + " is a " + mySecondWord + " & " + myThirdWord + " " + myFourthWord + ".";
// // console.log(FinalSentence);
// // 

// assert( //
//     (function() {
//         count = 0;
//         let out = cc(10);
//         const hasSpace = /-?\d+ (Bet|Hold)/.test('' + out);
//         return hasSpace;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(2);
//         cc(3);
//         cc(4);
//         cc(5);
//         var out = cc(6);
//         if (out === '5 Bet') {
//             return true;
//         }
//         return false;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(7);
//         cc(8);
//         var out = cc(9);
//         if (out === '0 Hold') {
//             return true;
//         }
//         return false;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(10);
//         cc('J');
//         cc('Q');
//         cc('K');
//         var out = cc('A');
//         if (out === '-5 Hold') {
//             return true;
//         }
//         return false;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(3);
//         cc(7);
//         cc('Q');
//         cc(8);
//         var out = cc('A');
//         if (out === '-1 Hold') {
//             return true;
//         }
//         return false;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(2);
//         cc('J');
//         cc(9);
//         cc(2);
//         var out = cc(7);
//         if (out === '1 Bet') {
//             return true;
//         }
//         return false;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(2);
//         cc(2);
//         var out = cc(10);
//         if (out === '1 Bet') {
//             return true;
//         }
//         return false;
//     })()
// );


// assert(
//     (function() {
//         count = 0;
//         cc(3);
//         cc(2);
//         cc('A');
//         cc(10);
//         var out = cc('K');
//         if (out === '-1 Hold') {
//             return true;
//         }
//         return false;
//     })()
// );


// let count1 = 0;

// function cc(card) {
//     // Only change code below this line


//     return "Change Me";
//     // Only change code above this line
// }

// cc(2);
// cc(3);
// cc(7);
// cc('K');
// cc('A');

// let count = 0;

// function cc(card) {
//     switch (card) {
//         case 2:
//         case 3:
//         case 4:
//         case 5:
//         case 6:
//             count++;
//             break;
//         case 10:
//         case 'J':
//         case 'Q':
//         case 'K':
//         case 'A':
//             count--;
//     }
//     if (count > 0) {
//         return count + " Bet";
//     } else {
//         return count + " Hold";
//     }
// }