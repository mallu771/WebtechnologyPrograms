let a = [1, 'A', "hi", true, undefined, null, function a() {}]
console.log(a);
console.log(typeof a);
console.log(Array.isArray(a));

//arrays methods
//push
let array = [100, 200, 300, 400]
console.log(array.push("500", "hi"));
console.log(array);

//unshift
let array1 = [100, 200, 300, 400];
console.log(array1.unshift("000"));
console.log(array1);

//pop
let array2 = [100, 200, 300, 400];
console.log(array2.pop()); //no need pop
console.log(array2);

//shift
let array3 = [100, 200, 300, 400];
console.log(array3.shift());
console.log(array3);

//slice method it include starting index, excludes last ending index
let array4 = [200, 400, 550, 600, 700];
console.log(array4.slice(1, 4));
console.log(array4);

//splice
let array5 = [100, 200, 300, 400, 500, 600, 700];
console.log(array5.splice(2, 4, "hi", "hello", 'eee'));
console.log(array5);

//fill method
let array6 = [200, 400, 500, 600, 700];
console.log(array6.fill("mallu"));
console.log(array6);

//concat
let array7 = [200, 300, 400, 500, 600, 700];
let array8 = ["bad", "good"]
console.log(array7.concat(array8));

//includes
let array9 = [100, 200, 300, 500, 400, 700];
console.log(array9.includes(150));
//join
let array10 = [10, 20, 30, 40, 50];
console.log(array10.join(""));
//reverse
let array11 = [20, 30, 40, 50, 10];
console.log(array11.reverse());
//split
let array12 = "hi hello bye";
console.log(array12.split(" "));

let array122 = []; //empty array
let n = 122;
console.log(array122);
console.log(typeof array122);
console.log(Array.isArray(array122));
console.log(Array.isArray(n));

let array124 = [10];
console.log(array124);

let array126 = [1000, 2000, 300, 400, 500, 654];
console.log(array126);
console.log(array126.length); //6
console.log(array[8]); //undefined

array126[8] = "last value";
console.log(array126);
array126[2] = "D boss";
console.log(array126);

delete array126[2];
console.log(array126);

delete array126[8];
console.log(array126);