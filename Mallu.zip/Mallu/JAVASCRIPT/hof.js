// //immediate invoke function exception

// (function() {
//     console.log("iam java");
// })()
// //hof
// function hof(a, b, task) {
//     res = task(a, b);
//     return res;

// }
// let add = (10, 30, function hof(a, b) {
//     return 20 + 40;
// })
// console.log(add());
// let sub = (10, 30, function hof(a, b) {
//     return 20 - 40;
// })
// console.log(sub());
// let mul = (10, 30, function hof(a, b) {
//     return 20 * 40;
// })
// console.log(mul());
// let div = (10, 30, function hof(a, b) {
//     return 20 / 40;
// })
// console.log(div());
// //nested function
// function one() {
//     var a = 20;

//     function two() {
//         var b = 30;
//         console.log(a);


//         function three() {
//             var c = 50;
//             console.log(b);
//             console.log(c);
//         }
//         return three
//     }
//     return two
// }
// one()()()

//hof
// function hof(x, y, task) {
//     a = task(x, y);
//     return a;
// }
// let add1 = hof(20, 40, function(x, y) {
//     return x + y;
// })
// console.log(add1);
// let sub1 = hof(20, 40, function(x, y) {
//     return x - y;
// })
// console.log(sub1);
// let mul1 = hof(20, 40, function(x, y) {
//     return x * y;
// })
// console.log(mul1);
// let div1 = hof(20, 40, function(x, y) {
//     return x / y;
// })
// console.log(div1);

//Asynchronized
console.log("execute 1");
setTimeout(function() {
    console.log("execute 2");
}, 1000)
console.log("execute 3");

// function hof(a, b, task) {
//     return res = task(a, b);
// }

// let add = hof(10, 30, function(a, b) {
//     return a + b;
// })
// console.log(add);

// function one() {
//     var a = 10;

//     function two() {
//         var b = 20;
//         var c = 30;
//         console.log(a);

//         function three() {
//             console.log(b);
//             console.log(c);
//         }
//         three()
//     }
//     two()
// }
// one()

// function hof(a, b, task) {
//     res = task(a, b);
//     return res;
// }

// var add1 = hof(10, 20, function(a1, b1) {
//     return 12 + 20;
// })
// console.log(add1);

// var sub2 = (20, 10, function hof(a, b) {
//     return 20 - 10;
// })
// console.log(sub2());
console.log("hi");
setTimeout(function() {
    console.log("hello");
}, 1000);
console.log("Raju");