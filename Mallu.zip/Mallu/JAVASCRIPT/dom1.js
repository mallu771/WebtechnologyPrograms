//key events

let key = document.getElementById('demo2');
key.addEventListener('keydown', () => {
    console.log('keydown');
})


let key1 = document.getElementById('demo1');
key1.addEventListener('keypress', () => {
    console.log('keypress');

})

let btn10 = document.getElementById('demo');
btn10.addEventListener('keyup', () => {
    let rc = Math.floor(Math.random() * 10000)
    console.log(rc);
    // document.body.style.backgroundColor = '#${rc}';
})
let d = document.querySelector('#mm');
d.addEventListener('mousedown', () => {
    document.body.style.padding = "20px";
    document.body.style.border = "10px solid red";
    document.body.style.backgroundColor = "yellow";
    document.body.style.width = "400px";
    document.body.style.height = "400px";
    // document.body.style.backgroundColor = "red";
    document.body.style.borderRadius = "10px";
})