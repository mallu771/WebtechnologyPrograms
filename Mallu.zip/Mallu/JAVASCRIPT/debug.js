var a = 100;
console.log(a);
let b = 200;
const c = 300;
console.log(c);
console.log(b);

function test() {

    let d = 50;
    console.log(d);
}
test();