//map method
let number = [1, 2, 3, 4];
let dn = number.map(n => n * 2);
console.log(dn);
let number2 = [1, 2, 3, 4];
let dn2 = number2.map(n => n + 2);
console.log(dn2);

//filter method
let number1 = [1, 2, 3, 4];

let dn1 = number1.filter(n => n > 1);
console.log(dn1);

//reduce method
// let number3 = [1, 2, 3, 4, 5];
// let initialValue = 0;
// let result = number3.reduce((accu, value) =>
//     value + accu, initialValue
// )
// console.log(result);

// let n = [3, 4, 2, 6, 7];
// let initialValue = 10;
// let n1 = n.reduce((value, acc) =>
//     value + acc, initialValue
// )
// console.log(n1);
let n2 = [3, 4, 5, 6, 5];
let initialValue = 10;
let m = n2.reduce((acc, value) => {
    value + acc, initialValue
})
console.log(m);