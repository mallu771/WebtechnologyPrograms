// let a = 2;
// let b = 4;
// let c = (a + b);
// document.write(c);
// document.writeln(c);
// document.write("hi hello bye");
// document.writeln(c);
// document.writeln(c);
// // document.writeln(c);
// alert("i am lukey");

// let p = 10;
// let q = 20;

// let r = (p + q);
// console.log(r);

// let m = prompt("enter value of a");
// let n = prompt("enter value of b");
// let o = (m * n);
// console.log(o);
// document.write(o);
// alert("hi im mallu");
// let m = prompt("Enter value A");
// let n = prompt("Enter value B");
// let o = (m + n);
// console.log(o);
// confirm("i am tamil bro");
// alert("i am lukey");
// let m = Number(prompt("Enter value A"));
// let n = Number(prompt("Enter value B"));
// let o = (m + n);
// console.log(o);
// alert("i am lukey");