// let element = document.getElementById('demo').innerHTML = "Welcome 2023";
// console.log(element);
// // //innerHTML is update the values
// let element2 = document.getElementById('demo').innerHTML = "good bye 2022";
// console.log(element2);
// let element1 = document.getElementsByClassName('test').innerHTML = "hi gelaya";
// console.log(element1);
// // // dom methods 
// // 1.get element by id
// let d = document.getElementById('demo').style.background = "green";
// document.writeln(d);
// let d1 = document.getElementById('demo').style.background = "red";
// document.write(d1);

// let ele11 = document.createElement('h2');
// console.log(ele11);
// ele11.innerHTML = "new year";

// let z1 = document.getElementsByClassName('test');
// console.log(z1);
// console.log(z1[1]);
// console.log(Array.isArray(z1));

// let c1 = document.getElementsByTagName('p');
// console.log(c1);

// let m = document.querySelector('#demo2');
// console.log(m);

// let m1 = document.querySelectorAll('#demo2');
// console.log(m1);

// let m2 = document.getElementsByName('hi')
// console.log(m2);

// 2 method
// let btn = document.querySelector('#demo3');
// console.log(btn);
// btn.onclick = () => {
//     document.body.style.backgroundColor = "black";
// }

// let ba1 = document.querySelector('.mm');
// console.log(ba1);
// ba1.onclick = () => {
//         document.body.style.backgroundColor = "red";
//     }
//     // // 1 method

// function test() {
//     document.body.style.backgroundColor = "blue";
// }
// test()
//     //     // 3 method
// let btn1 = document.querySelector('#demo4');
// // console.log(btn1);
// btn1.onclick = () => {
//     document.body.style.backgroundColor = "yellow";
// }

// btn3 = document.querySelector('button');
// btn3.addEventListener('click', () => {
//     document.body.style.backgroundColor = "pink";
// })

//create elements
// let element11 = document.createElement("input");
// console.log(element11);
// element11.innerHTML = "box";
// document.body.appendChild(element11)

let ele = document.createElement('nav');
ele.setAttribute('id', 'test');
document.body.appendChild(ele);

let e = document.createElement('input');
console.log(e);
e.innerHTML = "box"
document.body.appendChild(e)

let v = document.createElement('div');
v.setAttribute('id', 'c');
document.body.appendChild(v)