//string
// let d = "pmc";
// let d1 = 'pmc';
// let d2 = `pmc2`;
// console.log(typeof d);
// console.log(typeof d1);
// console.log(typeof d2);

// let d3 = "'hi'";
// let d4 = '"hello"';
// let d5 = `good`;
// console.log(d3);
// console.log(d4);
// console.log(d5);

// let d6 = "praveen";
// let d7 = 101;
// let d8 = 10000;
// console.log(`${d6} is ${d6} of id ${d7} earning ${d8}`);

let v1 = "puneeth rajkumar";
// console.log(v1.length);
// console.log(v1.endsWith("a"));
// console.log(v1.startsWith("p"));
// console.log(v1.charAt(5));
// console.log(v1.indexOf("e"));
// console.log(v1.slice(0, 7));
// console.log(v1.split('').reverse('').join(''));
console.log(v1.split(' ').reverse().join(''));