//Anonymous fuction
function demo() {
    console.log("hello");
}
demo();
let a11 = function() {
    console.log("hi");
}
a11();

//named function
function demo1() {
    console.log("naughty");
}
console.log(demo);
console.log(demo());
demo1();

//first class fuction
let s = function() {
    console.log("xyz");
}
s();

//function with expresstion
let d1 = function() {
    console.log("abc");
}
d1();

//arrrow fuction
let z1 = () => {
    console.log("good afternoon");
}
z1();
console.log(typeof z1);

let g1 = () => {
        return "hiiii"
            // console.log(g1());
    }
    // console.log(g1());
console.log(g1);