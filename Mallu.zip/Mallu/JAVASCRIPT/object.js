// let a = new Boolean(true)
// console.log(a);

// let a1 = new String("true")
// console.log(a1);

// //object literal

// let mb = {
//     id: 100,
//     name: "mallu",
//     place: "belagavi",
//     address: {
//         city: "bengalore",
//         pincode: 591304
//     }
// }
// console.log(mb);
// console.log(mb.name);
// console.log(mb.id);
// console.log(mb.place);
// console.log(mb.address.city);
// console.log(mb.address.pincode);
// console.log(mb.id = 105);
// console.log(mb.address.city = "vijayapura");
// console.log(mb.place = "mysore");
// console.log(mb.marks = 1000); //add new key value pair
// console.log(mb);
// console.log(mb.address.landmark = "pmc");
// console.log(mb);
// console.log(mb.name = "Raju");
// console.log(mb.id = 108);
// console.log(mb.friend = "harsha");
// console.log(mb);

// // // //88888888888
// let mb1 = {
//     id: 110,
//     name: "abc",
//     address: function abort() {
//         let city = "belagavi"
//         let pin = 591404
//         return `${city} ${pin}`
//     }
// }
// console.log(mb1.address());

let mb2 = {
    id: 143,
    name: "Mallu",
    place: "Katageri",
    address: function abort() {
        let city = "belagavi";
        let pin = 45678;
        return `${city} ${pin}`
    }
}
console.log(mb2.address());

//assignment
// console.log(d);
// let a11 = 11;
// const b = 12;
// var d = 12;
// console.log(b);
// console.log(a11);

// function g() {
//     let b = 10;
//     console.log(b);
//     let c = 12;
// }
// g()

// console.log(d);
// let v = 10;
// const v1 = 15;
// var v2 = 20;
// console.log(v2);
// console.log(v);

// function min() {
//     let f = 200;
//     console.log(f);
//     console.log(v1);
// }
// min()
//otp generate
// let obj = {
//     id: 101,
//     Name: "abc",
//     address: () => {
//         let city = "bengalore";
//         let pincode = 56743;
//         return `${city} ${pincode}`
//     }
// }
// console.log(obj.address());

// let d = {
//     id: 100,
//     name: "mallu",
//     address: () => {
//         let pin = 101;
//         let city = "ben";
//         return `${pin} ${city}`
//     }
// }
// console.log(d.address());
// let obj1 = {
//     id: 101,
//     Name: "abc",
//     address: function() {
//         return this.id;
//     }
// }
// console.log(obj1.address());
// let o1 = {
//     id: 111,
//     Nmae: "ban",
//     address: function() {
//         return this.id;
//     }
// }
// console.log(o1.address());
// let Ename = "mallu";
// let obj2 = {
//     id: 101,
//     Name: "abc",
//     address: function() {
//         return this.Ename;
//     }
// }
// console.log(obj2.address());
// Math object
// console.log(Math.round(11.5));
// console.log(Math.ceil(456.4));
// console.log(Math.floor(101.6));
// console.log(Math.sqrt(9));
// console.log(Math.random() * 1000);
// console.log(Math.ceil((Math.random() * 10000)));
// console.log(Math.ceil((Math.random() * 10000)));

// let v1 = Math.ceil(Math.random() * 100000).toString(26);
// console.log(v1);
// console.log(Math.ceil(Math.random() * 10000).toString(26));
//color changes
// let r = Math.ceil(Math.random() * 100000).toString(26);
// h1 = document.querySelector("h1");

// h1.style.background = `#${r}`;
// console.log(h1);

//time object
// setTimeout(() => {
//     console.log("hi mallu");
// }, 2000)
// setTimeout(() => {
//     console.log("hi tamil");
// }, 5000)
// setInterval(() => {
//     console.log("hi rohit");
// }, 4000)
// setTimeout(() => {
//     console.log("hi lakki");
// }, 4000)
// setTimeout(() => {
//     console.log("hi");
// }, 1000)
// setTimeout(() => {
//     console.log("hello");
// }, 5000);
// setTimeout(() => {
//     console.log("hey");
// }, 3000);
// setTimeout(() => {
//     console.log("mallu");
// }, 500);

//time
// let dt = new Date();
// console.log(dt);

// console.log(dt.getDate());
// console.log(dt.getFullYear());
// console.log(dt.getDay());
// console.log(dt.getMonth());
// console.log(dt.getMilliseconds());
// console.log(dt.getSeconds());

//keys values entries
// let kabi = {

//     id: 236,
//     name: "cxz"
// }
// console.log(Object.keys(kabi));
// let kabi1 = {

//     id: 234,
//     name: "csgfgz"
// }
// console.log(Object.values(kabi1));
// let kabi2 = {

//     id: 233,
//     name: "cxz"
// }
// console.log(Object.entries(kabi2));

//seal method

let dekh = {

    id: 123,
    name: "hjk"
}
console.log(dekh);
console.log(Object.seal(dekh));
dekh.id = "110";
console.log(dekh);
dekh.place = "hubli"
console.log(dekh);

//freeze
let n = {
    id: 111,
    name: "mallu"
}
console.log(n);
console.log(Object.freeze(n));
console.log(n.id = 432);
console.log(n);
console.log(n.city = "belagavi");
console.log(n);

//frozen
// let n1 = {
//     id: 111,
//     name: "virat"
// }
// console.log(n1);
// console.log(Object.isSealed(n1));
// console.log(Object.isFrozen(n1));